///*
// 
// 	TODO
// 
// */
//
//package test.java.alkolexa;
//
//import junit.framework.TestCase;
//
//public class AlkolexaStreamHandlerTest extends TestCase {
//
//}
